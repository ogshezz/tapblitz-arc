# TapBlitz — Arc Arcade DApp 🎮

A phone-friendly mini-game for Arc Testnet. Tap the energy orb for 15 seconds, connect an EVM wallet, and submit a personal-best score to an onchain leaderboard.

![TapBlitz](https://img.shields.io/badge/Arc-Testnet-6EA8FF)
![Solidity](https://img.shields.io/badge/Solidity-0.8.x-363636)
![License](https://img.shields.io/badge/License-MIT-green)

## Features

- Play without a wallet
- Mobile-first arcade interface
- EVM wallet connection
- Arc Testnet network switching
- Solidity leaderboard contract
- Onchain personal-best scores and top-player ranking
- No tokens, bets, entry fees, or prizes

## Project structure

```text
tapblitz-arc/
├── .github/
│   └── workflows/
│       └── pages.yml
├── contracts/
│   └── TapBlitzLeaderboard.sol
├── .gitignore
├── index.html
├── LICENSE
└── README.md
```

## Run locally

You can open `index.html` in a browser, or serve the project using Python:

```bash
python -m http.server 8080
```

Then open `http://127.0.0.1:8080`.

The frontend loads ethers.js from jsDelivr, so internet access is required.

## Deploy the smart contract to Arc Testnet

1. Open [Remix IDE](https://remix.ethereum.org).
2. Create `TapBlitzLeaderboard.sol` and paste in the code from `contracts/TapBlitzLeaderboard.sol`.
3. Compile using Solidity `0.8.24` or a compatible `0.8.x` compiler.
4. In your EVM wallet, add/select Arc Testnet:
   - Network: `Arc Testnet`
   - RPC: `https://rpc.testnet.arc.io`
   - Chain ID: `5042002`
   - Currency symbol: `USDC`
   - Explorer: [testnet.arcscan.app](https://testnet.arcscan.app)
5. Get testnet funds from the [Circle faucet](https://faucet.circle.com) if Arc Testnet is available there.
6. In Remix, select **Injected Provider**, verify the wallet is on Arc Testnet, deploy `TapBlitzLeaderboard`, and approve the transaction.
7. Copy the deployed contract address.
8. Open `index.html` and replace this line:

   ```js
   const CONTRACT_ADDRESS='';
   ```

   with your deployed address between the quotes.
9. Commit the updated `index.html` to GitHub and reload the site.
10. Connect your wallet, finish a round, and press **Save score onchain**.

## Publish with GitHub Pages

This repository includes a GitHub Actions workflow at `.github/workflows/pages.yml`.

1. Create a new **public** GitHub repository, for example `tapblitz-arc`.
2. Upload all files and folders in this project to the repository root.
3. In GitHub, open **Settings → Pages**.
4. Under the build/deployment source, choose **GitHub Actions**.
5. Push to the `main` branch or run the workflow manually from **Actions**.
6. When the workflow finishes, GitHub will show your published site URL in **Settings → Pages** or the workflow run.

## Important limitations

- The contract is not deployed by this repository; deployment is a separate step.
- The app has not been independently security-audited or end-to-end tested.
- Scores are self-reported, so this is a demo leaderboard rather than cheat-proof competitive gaming.
- The contract tracks at most the first 20 wallets that submit a valid personal best.
- Test on Arc Testnet only. Never enter or share your wallet seed phrase with a website or developer.
