// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title TapBlitzLeaderboard
/// @notice Stores each player's personal best and exposes a small top-player leaderboard.
/// @dev No tokens, bets, prizes, or admin controls. Scores are self-reported by players.
contract TapBlitzLeaderboard {
    uint256 public constant MAX_PLAYERS = 20;
    mapping(address => uint256) public bestScore;
    address[] private players;

    event ScoreSubmitted(address indexed player, uint256 score, uint256 previousBest);

    function submitScore(uint256 score) external {
        require(score > 0 && score <= 10000, "Score out of range");
        uint256 previous = bestScore[msg.sender];
        require(score > previous, "Not a new personal best");

        bestScore[msg.sender] = score;
        if (previous == 0 && players.length < MAX_PLAYERS) {
            players.push(msg.sender);
        }
        emit ScoreSubmitted(msg.sender, score, previous);
    }

    /// @notice Returns recorded players sorted by best score, descending.
    function getTopPlayers() external view returns (address[] memory topPlayers, uint256[] memory scores) {
        uint256 n = players.length;
        topPlayers = new address[](n);
        scores = new uint256[](n);
        for (uint256 i = 0; i < n; i++) {
            topPlayers[i] = players[i];
            scores[i] = bestScore[players[i]];
        }
        for (uint256 i = 0; i < n; i++) {
            for (uint256 j = i + 1; j < n; j++) {
                if (scores[j] > scores[i]) {
                    (scores[i], scores[j]) = (scores[j], scores[i]);
                    (topPlayers[i], topPlayers[j]) = (topPlayers[j], topPlayers[i]);
                }
            }
        }
    }
}